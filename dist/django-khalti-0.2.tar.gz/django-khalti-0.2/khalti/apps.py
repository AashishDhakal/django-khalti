from django.apps import AppConfig


class KhaltiConfig(AppConfig):
    name = 'khalti'
